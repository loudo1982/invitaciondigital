export default function Section({ id, title, children }) {
  return (
    <section id={id} className="container-p my-12">
      {title && (
        <div className="text-center mb-5">
          <h2 className="inline-block">{title}</h2>
          <div className="mx-auto mt-3 w-28 h-[2px] bg-gold-400/70 rounded-full" />
        </div>
      )}
      <div className="card p-6">{children}</div>
    </section>
  );
}
